# NightlyDownload
A quick &amp; simple download manager made in Bash for Mac OS X.

## Other Versions
Windows Version: [Nightlyy/NightlyDownload](https://github.com/Nightlyy/NightlyDownload)
